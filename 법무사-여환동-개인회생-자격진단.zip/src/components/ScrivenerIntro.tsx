import React, { useState } from 'react';
import { ShieldCheck, Phone, Award, CheckCircle, Scale, GraduationCap, MapPin, Check, FileCheck, Landmark } from 'lucide-react';
import { motion } from 'motion/react';

export default function ScrivenerIntro() {
  const [imgSrc, setImgSrc] = useState('/yeo_hwan_dong.png');
  const [showVector, setShowVector] = useState(true);

  React.useEffect(() => {
    // Check if PNG is available
    const pngImg = new Image();
    pngImg.src = '/yeo_hwan_dong.png';
    pngImg.onload = () => {
      setImgSrc('/yeo_hwan_dong.png');
      setShowVector(false);
    };
    pngImg.onerror = () => {
      // Fallback to JPG
      const jpgImg = new Image();
      jpgImg.src = '/yeo_hwan_dong.jpg';
      jpgImg.onload = () => {
        setImgSrc('/yeo_hwan_dong.jpg');
        setShowVector(false);
      };
      jpgImg.onerror = () => {
        setShowVector(true);
      };
    };
  }, []);

  const YeoHwanDongAvatar = () => (
    <svg viewBox="0 0 400 400" className="w-full h-auto aspect-square rounded-xl object-cover bg-slate-100 transition duration-300 group-hover:scale-[1.02]">
      {/* Background (Smooth studio grey) */}
      <rect width="400" height="400" fill="#E2E8F0" />
      
      {/* Studio Spot Backdrop glow */}
      <circle cx="200" cy="180" r="160" fill="#F1F5F9" opacity="0.6" />
      
      {/* Body / Suit jacket */}
      <path d="M100,340 C100,280 140,240 200,240 C260,240 300,280 300,340 L300,400 L100,400 Z" fill="#1E293B" />
      {/* Grid Pattern overlay (subtle lines) */}
      <path d="M130,260 L130,400 M160,245 L160,400 M190,240 L190,400 M220,240 L220,400 M250,245 L250,400 M270,260 L270,400" stroke="#334155" strokeWidth="1" opacity="0.4" />
      
      {/* Shirt collar */}
      <polygon points="170,240 200,290 150,280" fill="#FFFFFF" />
      <polygon points="230,240 200,290 250,280" fill="#FFFFFF" />
      <polygon points="170,240 200,290 230,240" fill="#E2E8F0" />
      
      {/* Tie (Blue with gorgeous stripes matching the photo) */}
      <polygon points="190,270 210,270 215,380 200,400 185,380" fill="#2563EB" />
      {/* Tie diagonal stripes */}
      <path d="M188,290 L212,280" stroke="#60A5FA" strokeWidth="4" />
      <path d="M186,315 L214,305" stroke="#FFFFFF" strokeWidth="3" />
      <path d="M185,340 L215,330" stroke="#60A5FA" strokeWidth="4" />
      <path d="M185,365 L215,355" stroke="#FFFFFF" strokeWidth="3" />
      
      {/* Head shape */}
      <path d="M140,160 C140,95 260,95 260,160 C260,225 200,240 200,240 C200,240 140,225 140,160 Z" fill="#FFD0B3" />
      
      {/* Ears */}
      <circle cx="137" cy="165" r="14" fill="#EBB495" />
      <circle cx="263" cy="165" r="14" fill="#EBB495" />
      
      {/* Hair (Swept style matching the photo) */}
      <path d="M135,145 C130,120 150,90 200,85 C250,90 270,120 265,145 C260,148 250,135 245,130 C235,123 215,125 200,130 C185,125 165,123 155,130 C150,135 140,148 135,145 Z" fill="#0F172A" />
      {/* Detailed sideburns */}
      <path d="M137,137 L137,160 C137,160 142,145 146,145 Z" fill="#0F172A" />
      <path d="M263,137 L263,160 C263,160 258,145 254,145 Z" fill="#0F172A" />

      {/* Eyebrows */}
      <path d="M165,140 Q180,133 190,140" fill="none" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
      <path d="M235,140 Q220,133 210,140" fill="none" stroke="#0F172A" strokeWidth="3" strokeLinecap="round" />
      
      {/* Eyes */}
      <ellipse cx="178" cy="151" rx="6" ry="4" fill="#1E293B" />
      <ellipse cx="222" cy="151" rx="6" ry="4" fill="#1E293B" />
      
      {/* Smile (Warm and highly kind expression) */}
      <path d="M182,192 Q200,205 218,192" fill="none" stroke="#E11D48" strokeWidth="3" strokeLinecap="round" />
      <path d="M180,192 C181,192 181,195 183,194" fill="none" stroke="#1E293B" strokeWidth="1.5" />
      <path d="M220,192 C219,192 219,195 217,194" fill="none" stroke="#1E293B" strokeWidth="1.5" />
      
      {/* Nose */}
      <path d="M196,168 L200,178 L204,168" fill="none" stroke="#D1A084" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M192,178 Q200,183 208,178" fill="none" stroke="#D1A084" strokeWidth="2" strokeLinecap="round" />
      
      {/* Glasses (Elegant round glasses from the photo) */}
      <circle cx="178" cy="152" r="18" fill="none" stroke="#334155" strokeWidth="2.5" />
      <circle cx="178" cy="152" r="19" fill="none" stroke="#D97706" strokeWidth="0.8" opacity="0.6" />
      <circle cx="222" cy="152" r="18" fill="none" stroke="#334155" strokeWidth="2.5" />
      <circle cx="222" cy="152" r="19" fill="none" stroke="#D97706" strokeWidth="0.8" opacity="0.6" />
      <path d="M196,150 Q200,147 204,150" fill="none" stroke="#334155" strokeWidth="2.5" />
      <path d="M160,152 L140,147" fill="none" stroke="#334155" strokeWidth="2" />
      <path d="M240,152 L260,147" fill="none" stroke="#334155" strokeWidth="2" />
    </svg>
  );

  return (
    <section id="scrivener-intro" className="py-16 md:py-24 bg-gradient-to-b from-slate-50 to-slate-100 border-b border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center space-y-3 mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            대표법무사 소개
          </h2>
          <p className="text-sm sm:text-base text-slate-500 font-medium max-w-lg mx-auto">
            의뢰인의 든든한 동반자, 풍부한 실무 경험과 성공 사례를 갖춘 법무사 여환동이 직접 해결합니다.
          </p>
        </div>

        {/* Content Layout Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-start">
          
          {/* Photo Column */}
          <div className="md:col-span-5 flex flex-col items-center">
            <div className="relative group w-full max-w-[280px] md:max-w-none">
              {/* Outer Decorative Gradient Frame */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-emerald-600 to-teal-500 rounded-3xl blur-md opacity-30 group-hover:opacity-50 transition duration-300" />
              
              <div className="relative rounded-2xl bg-white p-2.5 shadow-xl border border-slate-200 overflow-hidden">
                {showVector ? (
                  <YeoHwanDongAvatar />
                ) : (
                  <img
                    src={imgSrc}
                    alt="법무사 여환동"
                    referrerPolicy="no-referrer"
                    className="w-full h-auto aspect-square object-cover rounded-xl bg-slate-100 transition duration-300 group-hover:scale-[1.02]"
                  />
                )}
                
                {/* Overlay Badge for direct oversight */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-slate-900/90 text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-lg flex items-center gap-1.5 whitespace-nowrap backdrop-blur-xs min-h-[22px]">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>울산지방법원 등록 법무사</span>
                </div>
              </div>
            </div>

            {/* Association & Qualifications badges under photo */}
            <div className="mt-5 w-full max-w-[280px] md:max-w-none space-y-2 text-center md:text-left bg-white p-4 rounded-xl border border-slate-200 shadow-3xs">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 justify-center md:justify-start">
                <Award className="w-3.5 h-3.5 text-emerald-600" />
                <span>대한법무사협회 정회원</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 justify-center md:justify-start">
                <FileCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>개인회생·파산면책 전담 센터 소장</span>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 justify-center md:justify-start">
                <MapPin className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                <span>울산 남구 법대로14번길 18 1층 (법원 앞)</span>
              </div>
            </div>
          </div>

          {/* Profile Details Column */}
          <div className="md:col-span-7 space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-100 text-[10px] font-extrabold text-emerald-700">
                  대표 직접 상담 원칙
                </span>
                <span className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-[10px] font-extrabold text-slate-600">
                  1:1 비밀 수임
                </span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-800 tracking-tight flex items-baseline gap-2">
                대표법무사 여환동
                <span className="text-sm font-bold text-slate-400">Yeo Hwan Dong</span>
              </h3>
            </div>

            {/* Signature greeting quote */}
            <div className="relative p-5 rounded-2xl bg-emerald-50/50 border border-emerald-100/50 text-xs sm:text-sm text-slate-700 font-medium leading-relaxed italic">
              <p className="relative z-10">
                &quot;매일 밤 부채 독촉으로 깊은 한숨을 쉬고 계실 의뢰인의 절박한 마음을 누구보다 잘 알고 있습니다. 개인회생은 법률이 부여한 정당한 재기권입니다. 사무실의 일반 직원이 대리 상담하는 것이 아닌, 제가 직접 꼼꼼히 검토하고 처음부터 끝까지 진심으로 조력하겠습니다.&quot;
              </p>
            </div>

            {/* Specialization List */}
            <div className="space-y-3">
              <h4 className="text-xs font-extrabold text-slate-800 uppercase tracking-widest flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-emerald-600" />
                법무사 여환동 사무소만의 3대 신뢰 약속
              </h4>
              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-md bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 font-bold" />
                  </div>
                  <div>
                    <h5 className="text-sm font-extrabold text-slate-800">1. 법무사가 상담하고 직접 검토 및 인가 수임</h5>
                    <p className="text-xs sm:text-xs text-slate-500 font-semibold mt-1 leading-relaxed">
                      의뢰자의 서류 접수부터 법원 보정 명령 대응까지, 자격이 불분명한 사무장이 아닌 법무사가 전 과정을 실책 책임지고 진행합니다.
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-md bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 font-bold" />
                  </div>
                  <div>
                    <h5 className="text-sm font-extrabold text-slate-800">2. 울산지방법원 회생법원 정밀 최적화 솔루션</h5>
                    <p className="text-xs sm:text-xs text-slate-500 font-semibold mt-1 leading-relaxed">
                      울산지방법원 앞 정문 초근접 거리에 상주하며, 영남 및 울산지역 관할 회생법원의 최신 실무 준칙과 판사 성향을 분석하여 기각 없는 높은 원금 탕감률을 유도합니다.
                    </p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-md bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 font-bold" />
                  </div>
                  <div>
                    <h5 className="text-sm font-extrabold text-slate-800">3. 100% 비밀주의 및 완벽한 독촉 방패 제공</h5>
                    <p className="text-xs sm:text-xs text-slate-500 font-semibold mt-1 leading-relaxed">
                      사무소 주소 대리 송달 처리 프로토콜을 가동하여 전 우편물의 사가 송달을 완벽 차단하며, 접수 후 3일 이내에 전화/방문 추심 전면 중단 명령을 받아냅니다.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct CTA button to call Scrivener Yeo */}
            <div className="pt-4 flex flex-col sm:flex-row gap-3">
              <a
                href="tel:010-5410-5679"
                className="flex-1 px-6 py-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-2xl transition-all shadow-md shadow-emerald-100/50 hover:shadow-lg flex items-center justify-center gap-2 text-sm sm:text-base cursor-pointer"
              >
                <Phone className="w-4.5 h-4.5 text-white animate-pulse" />
                법무사 1:1 직통 유선 무료상담
              </a>
              <a
                href="#main-landing-wrap"
                onClick={(e) => {
                  e.preventDefault();
                  const target = document.getElementById('qualification-start-anchor');
                  if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  } else {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }
                }}
                className="px-6 py-4 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-2xl transition-all flex items-center justify-center gap-1.5 text-sm cursor-pointer"
              >
                <Landmark className="w-4 h-4" />
                자가 진단 보고서 받아보기 ↗
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
